<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Google\Cloud\Vision\V1\Feature\Type;
use Google\Cloud\Vision\V1\ImageAnnotatorClient;
use Google\Cloud\Vision\V1\Likelihood;
use DB;
class GoogleOCRController extends Controller
{
    /**
     * open the view.
     *
     * @param 
     * @return void
     */
    public function index()
    {
        return view('googleOcr');
    }

    /**
     * handle the image
     *
     * @param 
     * @return void
     */
    public function submit(Request $request)
    {
       // exit;
        $input = $request->all();
      //  dd($input);
        if($request->file('image')) {
            $file = $request->file('image');
            $filename = time().'_'.$file->getClientOriginalName();
//echo $filename;
                   // File extension
                   $extension = $file->getClientOriginalExtension();
$filename = time().'.'.$extension;
                   // File upload location
                   $location = 'files';
                   $allowed = array('jpeg', 'png', 'jpg');
if(!in_array($extension,$allowed)){
    echo json_encode(array(
        'status'=>0,
        'msg'=>'Invalid file format.Only file allowed in png,jpg'
       )); 
}
                   // Upload file
                   $file->move($location,$filename);
                   $data['image_file']=$filename;
                   $data['text']=$input['imagetext'];
                   $date['upload_date'] = date('Y-m-d');
                   DB::table('tbl_image_details')->insert($data);
                   echo json_encode(array(
                    'status'=>1,
                    'msg'=>'File upload successfully'
                   ));  
        }else{
            echo json_encode(array(
                'status'=>0,
                'msg'=>'Please select file'
               ));   
        }
//         if($request->file('image')) {
// //            $response =  \OCR::scan($request->file('image'));
// // dd($response);
//             // convert to base64
//             $image = base64_encode(file_get_contents($request->file('image')));

//             $client = new ImageAnnotatorClient();
//              $client->setImage($image);
//              $client->setFeature("TEXT_DETECTION");
//             // $image = file_get_contents($request->file("image"));
//             // $response = $imageAnnotatorClient->textDetection($image);
//             // $texts = $response->getTextAnnotations();
//             // dd($texts);
//              $google_request = new GoogleCloudVision([$client],  'http://localhost/imageocr/public/auth.json');

//              $response = $google_request->annotate();

//              dd($response);
//         }
    }
}