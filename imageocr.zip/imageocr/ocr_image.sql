-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.24-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for ocr_image
CREATE DATABASE IF NOT EXISTS `ocr_image` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `ocr_image`;

-- Dumping structure for table ocr_image.tbl_image_details
CREATE TABLE IF NOT EXISTS `tbl_image_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_file` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'upload file',
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'image text',
  `upload_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table ocr_image.tbl_image_details: ~2 rows (approximately)
/*!40000 ALTER TABLE `tbl_image_details` DISABLE KEYS */;
INSERT INTO `tbl_image_details` (`id`, `image_file`, `text`, `upload_date`) VALUES
	(1, '1691344808_ocr.png', '73185875', NULL),
	(2, '1691344900_ocr.png', '73185875', NULL),
	(3, '1691345173.png', 'Tesseract sample', NULL),
	(4, '1691345332.png', 'Tesseract sample', NULL),
	(5, '1691345358.png', 'Mild Splendour of am variuuswesled Night!\r\nMather n; wadIy-workmg visions} haul!\r\nI watch my ghdmg, \\xhxlc with watery light\r\nThy weak eye glimmeys Lhmugh a ﬂeecy m1;\r\nAnd when than loves! thy pale on}: Io shmud\r\nBehind the gu(her\'d blackness lost on high;\r\nAnd who): (hon darkest [mm the wind-rent cloud\r\nThy plaud lightning m m awaken\'d sky.', NULL),
	(6, '1691345442.png', 'I\r\nVahdate your\r\ncustomers‘ idemity\r\n\\n 3 simple steps', NULL),
	(7, '1691345518.jpeg', '-A', NULL);
/*!40000 ALTER TABLE `tbl_image_details` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
