<!DOCTYPE html>
<html>
    <head>
        <title>Google Cloud Vision OCR</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src='https://cdn.rawgit.com/naptha/tesseract.js/1.0.10/dist/tesseract.js'></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    </head>
    <body>
        <div class="container">
            <div class="row mt-3">
                <form method="post" action="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="image" class="form-label">Select image:</label>
                        <input type="file" id="image" name="image" class="form-control" required>
                    </div>
                    <input type="submit" class="btn btn btn-primary" id="submit" value="Submit"/>
                </form>
            </div>
        </div>
    </body>
    <script>
        function getBase64(file) {
   var reader = new FileReader();
   reader.readAsDataURL(file);
   reader.onload = function () {
     console.log(reader.result);
   };
   reader.onerror = function (error) {
     console.log('Error: ', error);
   };
}
        $(document).ready(function(){
            $('#submit').click(function(e){
                e.preventDefault();
                if($('#image')[0].files.length === 0){
        alert("File Required");
        $('#image').focus();

        return false;
    }
    var filePath =  $('input[type=file]')[0].files[0].value;
         
            // Allowing file type
            var allowedExtensions =
                    /(\.jpg|\.jpeg|\.png|\.gif)$/i;
             
            if (!allowedExtensions.exec(filePath)) {
                alert('Invalid file type');
                fileInput.value = '';
                return false;
            }
                Tesseract.recognize( $('input[type=file]')[0].files[0]).then(function(result){

console.log(result.text);

//  alert(result.text);
var formData = new FormData();
formData.append('imagetext', result.text);
formData.append('action', 'previewImg');
// Attach file
formData.append('image', $('input[type=file]')[0].files[0]);
//getBase64($('input[type=file]')[0].files[0]);
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

$.ajax({
    url: "<?php echo e(url('/google-ocr')); ?>",
    data: formData,
    type: 'POST',
    dataType:'JSON',
    contentType: false, 
    processData: false, 
    success:function(response){
if(response.status==1){
alert(response.msg);
location.reload();

}else{
    alert(response.msg);

}
    },error:function(){

    }
});
            });

});
                
        });
    </script>
</html><?php /**PATH C:\xampp8\htdocs\imageocr\resources\views/googleOcr.blade.php ENDPATH**/ ?>